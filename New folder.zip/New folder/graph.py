import matplotlib.pyplot as plt
import matplotlib.animation as animation
import pandas as pd


# Load data from CSV
data = pd.read_csv("D:/Wireshark/codebug/result1.csv")




# Sample data storage
ip_address = "192.168.1.1"
timestamps = data['timestamp'].tolist()
user_data = data['active_users'].tolist()

# Define a threshold to detect an attack
ATTACK_THRESHOLD = 100  # Active users count above this is considered an attack

# Initialize figure and axis
fig, ax = plt.subplots()
line, = ax.plot([], [], label="Active Users", color='orange', lw=2)

# Set up graph parameters
def init():
    ax.set_xlim(0, 10)  # X-axis initially set for the first 10 seconds
    ax.set_ylim(0, 150)  # Adjusted Y-axis for up to 150 active users
    ax.set_title(f"Real-Time Active Users monitoring")
    ax.set_xlabel("Time (seconds)")
    ax.set_ylabel("Active Users")
    ax.legend(loc='upper left')
    return line,

# Update the graph with new data from CSV
def update(frame):
    # Get current data from CSV at the current frame (index)
    if frame < len(user_data):
        current_time = timestamps[frame]
        users = user_data[frame]

        # Update the line data with new active user counts
        line.set_data(timestamps[:frame+1], user_data[:frame+1])

        # Dynamically adjust the X-axis to match the timestamps
        ax.set_xlim(max(0, current_time - 10), current_time)

        # Adjust Y-axis dynamically based on the values
        max_y = max(user_data[:frame+1]) + 10
        ax.set_ylim(0, max_y)

        # Change line color if the number of users exceeds the attack threshold
        if users > ATTACK_THRESHOLD:
            line.set_color('red')  # Red color indicates an attack
        else:
            line.set_color('orange')  # Normal color

    return line,

# Animate the plot and update every second (1000 ms)
ani = animation.FuncAnimation(fig, update, init_func=init, blit=True, interval=1000)

# Optimize the layout and show the plot
plt.tight_layout()
plt.show()
