import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import time
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# Cache for resolved IPs to avoid redundant lookups
ip_cache = {}

# Store timestamps for IP lookups
traffic_data = []

# Store request counts per IP for traffic analysis
ip_request_count = {}

# Store blocked IPs
blocked_ips = set()

# Store potential threat IPs
potential_threats = set()

# Store previous attack data
attack_log = []

# Store historical data for ML
historical_data = []

# Thresholds for blocking and flagging threats
BLOCK_THRESHOLD = 10  # Number of requests to block
THREAT_THRESHOLD = 5   # Number of requests to flag as potential threat

# Load GeoIP data from CSV
def load_geoip_data(file_path):
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        print(f"Error loading GeoIP data: {e}")
        return pd.DataFrame()

# Function to update the traffic visualization plot
def update_plot(traffic_data):
    times = [data['time'] for data in traffic_data]
    counts = [data['count'] for data in traffic_data]

    plt.clf()  # Clear the current figure
    plt.plot(times, counts, marker='o', label='IP Lookups')

    for blocked_ip in blocked_ips:
        plt.axvline(x=blocked_ip, color='r', linestyle='--', label=f'Blocked {blocked_ip}')

    plt.title('Traffic Hike Monitoring with IP Blocking')
    plt.xlabel('Time')
    plt.ylabel('Number of IP Lookups')
    plt.xticks(rotation=45, ha='right')
    plt.legend(loc='upper left')
    plt.tight_layout()
    plt.pause(0.1)  # Pause to allow plot to update without blocking

# Function to track and plot traffic data
def track_traffic():
    current_time = datetime.now().strftime('%H:%M:%S')
    if traffic_data and traffic_data[-1]['time'] == current_time:
        traffic_data[-1]['count'] += 1
    else:
        traffic_data.append({'time': current_time, 'count': 1})
   
    update_plot(traffic_data)

# Function to check if an IP should be blocked or flagged
def check_ip_status(ip):
    ip_request_count[ip] = ip_request_count.get(ip, 0) + 1
   
    if ip_request_count[ip] >= BLOCK_THRESHOLD:
        print(f"Blocking IP {ip} due to excessive requests.")
        blocked_ips.add(ip)
        log_attack(ip, "Blocked due to excessive requests")
        return 'blocked'

    if ip_request_count[ip] == THREAT_THRESHOLD:
        print(f"Flagging IP {ip} as potential threat due to suspicious activity.")
        potential_threats.add(ip)
        log_attack(ip, "Flagged as potential threat")
        return 'threat'

    return 'safe'

# Function to log attack details
def log_attack(ip, pattern):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    attack_log.append({'ip': ip, 'pattern': pattern, 'timestamp': timestamp})
    print(f"Logged attack: IP {ip}, Pattern: {pattern}, Time: {timestamp} (Visible to host only)")

# Function to resolve IPs using a cache, and monitor traffic
def resolve_ip(ip, geoip_data):
    if ip in blocked_ips:
        print(f"Skipping blocked IP: {ip}")
        return None
   
    status = check_ip_status(ip)
    if status == 'blocked':
        return None

    if ip in ip_cache:
        return ip_cache[ip]
   
    # Look up the IP in the GeoIP DataFrame
    try:
        location_data = geoip_data[geoip_data['ip'] == ip].iloc[0]
        location = {
            'longitude': location_data['longitude'],
            'latitude': location_data['latitude'],
            'city': location_data['city'],
            'country': location_data['country']
        }
        ip_cache[ip] = location
        track_traffic()
        return location
    except Exception as e:
        print(f"Error resolving IP {ip}: {e}")
        ip_cache[ip] = None
        return None

def retKML(dstip, srcip, geoip_data):
    try:
        dst = resolve_ip(dstip, geoip_data)
        if not dst:
            print(f"Error: Could not resolve destination IP: {dstip}")
            return ''

        src = resolve_ip(srcip, geoip_data)
        if not src:
            print(f"Error: Could not resolve source IP: {srcip}")
            return ''

        dstlongitude, dstlatitude = dst['longitude'], dst['latitude']
        srclongitude, srclatitude = src['longitude'], src['latitude']

        kml = (
            '<Placemark>\n'
            '<name>%s to %s</name>\n'
            '<extrude>1</extrude>\n'
            '<tessellate>1</tessellate>\n'
            '<styleUrl>#transBluePoly</styleUrl>\n'
            '<LineString>\n'
            '<coordinates>%6f,%6f\n%6f,%6f</coordinates>\n'
            '</LineString>\n'
            '</Placemark>\n'
        ) % (srcip, dstip, srclongitude, srclatitude, dstlongitude, dstlatitude)

        return kml
    except Exception as e:
        print(f"Error generating KML: {e}")
        return ''

def plotIPs(geoip_data):
    # Dummy active users
    active_users = [{'username': 'user1', 'ip': '192.168.1.1'}, {'username': 'user2', 'ip': '192.168.1.2'}]
    dst_ip = '152.58.248.82'  # Sample destination IP
    for user in active_users:
        src_ip = user["ip"]
        print(f"Active user: {user['username']}, IP: {src_ip}")

        kmlPts = retKML(dst_ip, src_ip, geoip_data)
        if kmlPts:
            print(kmlPts)

        # Add historical data for ML training
        historical_data.append({'ip': src_ip, 'requests': ip_request_count.get(src_ip, 0)})

def display_potential_threats():
    """Display current potential threats or inform that there are none."""
    if potential_threats:
        print("Current potential threat active users:")
        for threat in potential_threats:
            print(f" - {threat}")
    else:
        print("Currently, there are no potential threats.")

def train_model():
    # Prepare historical data for training
    df = pd.DataFrame(historical_data)
    if df.empty:
        return None

    X = df[['requests']]  # Features
    y = [1 if ip in potential_threats else 0 for ip in df['ip']]  # Labels (1: threat, 0: safe)

    # Split into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train the model
    model = RandomForestClassifier()
    model.fit(X_train, y_train)

    # Evaluate the model
    y_pred = model.predict(X_test)
    print(classification_report(y_test, y_pred))

    return model

def main():
    plt.ion()  # Enable interactive plotting
    fig = plt.figure(figsize=(10, 6))

    # Load GeoIP data from CSV
    geoip_data = load_geoip_data('geoip_data.csv')  # Replace with your actual CSV file path

    while True:
        plotIPs(geoip_data)

        # Display current potential threat users
        display_potential_threats()

        # Train the model periodically
        if len(historical_data) > 50:  # Adjust as needed
            model = train_model()
            historical_data.clear()  # Clear after training

        # Display previous attacks (for host only, client won't see attack pattern)
        if attack_log:
            print("Previous attacks (for host only):")
            for attack in attack_log:
                print(f" - IP: {attack['ip']}, Time: {attack['timestamp']}")

        time.sleep(10)

if __name__ == '__main__':
    main()
