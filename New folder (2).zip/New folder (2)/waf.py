import boto3
import logging
import time
from botocore.exceptions import ClientError, EndpointConnectionError, NoCredentialsError

# Initialize AWS WAF and Shield clients
def init_aws_clients(region='us-east-1'):
    return boto3.client('wafv2', region_name=region), boto3.client('shield', region_name=region)

# Logger setup for live applications
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger()

# Retry Decorator to retry failed API calls
def retry_on_failure(retries=3, delay=2, backoff=2):
    def decorator_retry(func):
        def wrapper_retry(*args, **kwargs):
            attempt = 0
            while attempt < retries:
                try:
                    return func(*args, **kwargs)
                except (EndpointConnectionError) as e:
                    attempt += 1
                    wait_time = delay * (backoff ** (attempt - 1))
                    logger.warning(f"{e}: Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                except ClientError as e:
                    error_code = e.response['Error']['Code']
                    if error_code == 'Throttling':
                        attempt += 1
                        wait_time = delay * (backoff ** (attempt - 1))
                        logger.warning(f"Throttling: Retrying in {wait_time} seconds...")
                        time.sleep(wait_time)
                    elif error_code == 'AccessDeniedException':
                        logger.error(f"Access Denied: {e.response['Error']['Message']}. Please check your AWS permissions.")
                        break
                    else:
                        logger.error(f"AWS ClientError: {e.response['Error']['Message']}")
                        break
                except NoCredentialsError as e:
                    logger.critical("No AWS credentials found. Ensure your credentials are correctly configured.")
                    break
                except Exception as e:
                    logger.error(f"An unexpected error occurred: {str(e)}")
                    break
            logger.error(f"Max retries exceeded for function: {func.__name__}")
            return None
        return wrapper_retry
    return decorator_retry


# The rest of the code remains unchanged, but with the above fix to handle throttling correctly.


# Create an IP set for blacklisting malicious IPs
@retry_on_failure(retries=5, delay=2)
def create_ip_set(waf_client, name, scope, description, addresses):
    try:
        response = waf_client.create_ip_set(
            Name=name,
            Scope=scope,  # CLOUDFRONT for Global, REGIONAL for regional
            Description=description,
            IPAddressVersion='IPV4',
            Addresses=addresses,
            VisibilityConfig={
                'SampledRequestsEnabled': True,
                'CloudWatchMetricsEnabled': True,
                'MetricName': f'{name}-IPSet'
            }
        )
        logger.info(f'IP Set Created: {response["Summary"]["Id"]}')
        return response['Summary']['Id']
    except ClientError as e:
        logger.error(f'Failed to create IP Set: {e.response["Error"]["Message"]}')
        return None

# Create rate-based and geographic-based rules
@retry_on_failure(retries=5, delay=2)
def create_advanced_waf_rules(waf_client, name, scope, rate_limit, ip_set_id, geo_restrictions=None):
    rules = [
        {
            'Name': 'RateLimitRule',
            'Priority': 1,
            'Statement': {
                'RateBasedStatement': {
                    'Limit': rate_limit,
                    'AggregateKeyType': 'IP'
                }
            },
            'Action': {'Block': {}},
            'VisibilityConfig': {
                'SampledRequestsEnabled': True,
                'CloudWatchMetricsEnabled': True,
                'MetricName': 'RateLimitRule'
            }
        },
        {
            'Name': 'IPBlacklistRule',
            'Priority': 2,
            'Statement': {
                'IPSetReferenceStatement': {
                    'ARN': ip_set_id
                }
            },
            'Action': {'Block': {}},
            'VisibilityConfig': {
                'SampledRequestsEnabled': True,
                'CloudWatchMetricsEnabled': True,
                'MetricName': 'IPBlacklistRule'
            }
        }
    ]
    
    if geo_restrictions:
        geo_rule = {
            'Name': 'GeoBlockRule',
            'Priority': 3,
            'Statement': {
                'GeoMatchStatement': {
                    'CountryCodes': geo_restrictions
                }
            },
            'Action': {'Block': {}},
            'VisibilityConfig': {
                'SampledRequestsEnabled': True,
                'CloudWatchMetricsEnabled': True,
                'MetricName': 'GeoBlockRule'
            }
        }
        rules.append(geo_rule)

    try:
        response = waf_client.create_rule_group(
            Name=name,
            Scope=scope,
            Capacity=100,
            Rules=rules,
            VisibilityConfig={
                'SampledRequestsEnabled': True,
                'CloudWatchMetricsEnabled': True,
                'MetricName': name
            }
        )
        logger.info(f'Advanced WAF Rules Created: {response["Summary"]["Id"]}')
        return response['Summary']['Id']
    except ClientError as e:
        logger.error(f'Failed to create rule group: {e.response["Error"]["Message"]}')
        return None

# Create a Web ACL and attach the rules
@retry_on_failure(retries=5, delay=2)
def create_web_acl(waf_client, name, scope, rules):
    try:
        response = waf_client.create_web_acl(
            Name=name,
            Scope=scope,
            DefaultAction={'Allow': {}},
            Rules=rules,
            VisibilityConfig={
                'SampledRequestsEnabled': True,
                'CloudWatchMetricsEnabled': True,
                'MetricName': name
            }
        )
        logger.info(f'Web ACL Created: {response["Summary"]["Id"]}')
        return response['Summary']['Id']
    except ClientError as e:
        logger.error(f'Failed to create Web ACL: {e.response["Error"]["Message"]}')
        return None

# Enable AWS Shield Advanced for further protection
@retry_on_failure(retries=3, delay=5)
def enable_shield_protection(shield_client, resource_arn):
    try:
        response = shield_client.create_protection(
            Name='MyShieldProtection',
            ResourceArn=resource_arn
        )
        logger.info(f'Shield protection enabled for resource: {resource_arn}')
        return response['ProtectionId']
    except ClientError as e:
        logger.error(f'Failed to enable Shield protection: {e.response["Error"]["Message"]}')
        return None

# Main deployment logic with advanced protection strategies
def deploy_advanced_waf_and_shield(malicious_ips, rate_limit, geo_restrictions, resource_arn, region='us-east-1'):
    waf_client, shield_client = init_aws_clients(region)
    
    try:
        # Create IP set for malicious IPs
        ip_set_id = create_ip_set(waf_client, "MaliciousIPs", "REGIONAL", "Set of blocked IPs", malicious_ips)
        if not ip_set_id:
            raise RuntimeError("Failed to create IP set, aborting deployment.")

        # Create advanced WAF rules
        rule_group_id = create_advanced_waf_rules(waf_client, "MyAdvancedWAFRules", "REGIONAL", rate_limit, ip_set_id, geo_restrictions)
        if not rule_group_id:
            raise RuntimeError("Failed to create advanced WAF rules, aborting deployment.")

        # Apply the rules in Web ACL
        web_acl_id = create_web_acl(waf_client, "MyWebACL", "REGIONAL", [
            {
                'Name': 'RateLimitAndIPBlocking',
                'Priority': 1,
                'Statement': {
                    'RateBasedStatement': {
                        'Limit': rate_limit,
                        'AggregateKeyType': 'IP'
                    }
                },
                'Action': {'Block': {}},
                'VisibilityConfig': {
                    'SampledRequestsEnabled': True,
                    'CloudWatchMetricsEnabled': True,
                    'MetricName': 'RateLimitRule'
                }
            }
        ])
        if not web_acl_id:
            raise RuntimeError("Failed to create Web ACL, aborting deployment.")
        
        # Enable AWS Shield Advanced protection for the resource
        shield_protection_id = enable_shield_protection(shield_client, resource_arn)
        if not shield_protection_id:
            raise RuntimeError("Failed to enable AWS Shield Advanced protection.")

        logger.info(f'Successfully deployed WAF and Shield protection with Web ACL ID: {web_acl_id}')

    except RuntimeError as e:
        logger.critical(f'Deployment failed: {e}')
    except ClientError as e:
        logger.critical(f'AWS ClientError during deployment: {e.response["Error"]["Message"]}')
    except NoCredentialsError:
        logger.critical("AWS credentials are missing. Please set up your credentials correctly.")
    except Exception as e:
        logger.critical(f'Unexpected error during deployment: {e}')

if __name__ == "__main__":
    # Default values, can be modified as needed
    malicious_ips = ["192.168.1.1/32", "203.0.113.0/24"]
    rate_limit = 2000  # Adjust rate limit as needed
    geo_restrictions = ['CN', 'RU']  # Block traffic from China and Russia
    resource_arn = 'arn:aws:cloudfront::123456789012:distribution/E1234567890ABC'  # Replace with your CloudFront distribution ARN
    
    deploy_advanced_waf_and_shield(malicious_ips, rate_limit, geo_restrictions, resource_arn)
