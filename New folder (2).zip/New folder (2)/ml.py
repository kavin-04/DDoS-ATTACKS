import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# Load and preprocess data
def load_data():
    # Example attack data (traffic_volume, request_frequency, packet_size)
    # Replace this with real-world attack sequence data
    data = {
        'traffic_volume': [100, 200, 300, 400, 1000, 1500, 500],
        'request_frequency': [10, 15, 20, 25, 30, 35, 40],
        'packet_size': [50, 60, 70, 80, 90, 100, 110],
    }
    
    df = pd.DataFrame(data)
    return df

# Function to preprocess the data
def preprocess_data(df):
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(df)
    
    # Preparing data for LSTM (samples, time steps, features)
    X = []
    y = []
    time_steps = 3  # Choose the number of steps for looking back

    for i in range(len(scaled_data) - time_steps):
        X.append(scaled_data[i:i + time_steps, :])
        y.append(scaled_data[i + time_steps, 0])  # Predicting traffic volume as next step

    X = np.array(X)
    y = np.array(y)
    return X, y, scaler

# Building the LSTM model
def build_lstm_model(input_shape):
    model = Sequential()
    model.add(LSTM(64, return_sequences=True, input_shape=input_shape))
    model.add(LSTM(64))
    model.add(Dense(1))  # Output layer predicting the next step in the sequence

    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

# Predicting next move
def predict_next_move(model, X_test):
    prediction = model.predict(X_test)
    return prediction

# Main function to run everything
def main():
    # Step 1: Load the data
    df = load_data()

    # Step 2: Preprocess the data for LSTM
    X, y, scaler = preprocess_data(df)
    X_train, y_train = X[:-1], y[:-1]  # Training on previous attack sequences
    X_test = X[-1:]  # Testing on the last sequence for prediction

    # Step 3: Build and train the LSTM model
    model = build_lstm_model((X_train.shape[1], X_train.shape[2]))
    model.fit(X_train, y_train, epochs=50, batch_size=1)
 # Step 4: Predict the next move based on the last sequence
    next_move = predict_next_move(model, X_test)
    next_move_rescaled = scaler.inverse_transform([[next_move[0][0], 0, 0]])[0][0]  # Rescale the traffic volume back

    print(f"Predicted next move (traffic volume): {next_move_rescaled}")

    # Step 5: Take action based on prediction
    if next_move_rescaled > 1200:  # Example threshold to trigger prevention
        print("Attack predicted! Taking preventive action...")
        prevent_attack()

# Prevent attack (simulated action)
def prevent_attack():
    # Add real prevention logic here (e.g., block IP, rate limit traffic)
    print("Blocking traffic and alerting system...")

if __name__ == "__main__":
    main()


